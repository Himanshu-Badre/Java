package Array;

import java.util.Arrays;

//wap to remove ',' from last index
public class LastComma {
public static void main(String[] args) {
	int arr[]= {1,5,7,9,8,5,};
	int arr1[] = new int[-2];
	arr1[-1]=22;
	arr1[0]=22;
	System.out.println(Arrays.toString(arr1));
	
//	for(int i=0;i<arr.length;i++) {
//		System.out.print(arr[i]);
//		if(i<arr.length-1) {
//			System.out.print(",");
//		}
//	}
}
}
